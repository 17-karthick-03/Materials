import sqlite3

def create_login_table():
    conn = sqlite3.connect('exam.db')
    cursor = conn.cursor()

    # Create login table if not exists
    cursor.execute('''CREATE TABLE IF NOT EXISTS login (
                        reg_num TEXT,
                        dob TEXT
                    )''')

    # Insert data into login table
    login_data = [
        ("142222104073", "17032005"),
        ("142222104064", "27082004"),
        ("142222104087", "13092004"),
        ("142222104062", "04102003"),
        ("142222104063", "25062005"),
        ("142222104092", "17082004"),
        ("142222104093", "23022005"),
        ("142222104116", "27112004"),
        ("142222104091", "14092004")

    ]

    cursor.executemany("INSERT INTO login VALUES (?, ?)", login_data)

    conn.commit()
    conn.close()

# Create login table and insert data
create_login_table()
