from tkinter import *
import csv

def record_check():
    with open('record.csv', newline='') as file:
        reader = csv.reader(file)
        records_data = list(reader)
    with open('approved.csv', newline='') as approved_file:
        approved_reader = csv.reader(approved_file)
        approved_data = set(tuple(row) for row in approved_reader)
    difference = [record for record in records_data if tuple(record) not in approved_data]
    return difference

def track(name, phone):
    found = False
    with open('record.csv', newline='') as record_file:
        reader = csv.reader(record_file)
        for row in reader:
            if row[0] == name and row[2] == phone:
                found = True
                break
    if found:
        with open('approved.csv', newline='') as approved_file:
            reader = csv.reader(approved_file)
            for row in reader:
                if row[0] == name and row[2] == phone:
                    track_1(True)
                    return
        track_1(False)
    else:
        track_1(None)

def track_1(found):
    track_window = Tk()
    track_window.geometry('200x80')
    track_window.title("Passport Verification Status")
    if found == True:
        status_label = Label(track_window, text="")
        status_label_1 = Label(track_window, text="Your Passport")
        status_label_2 = Label(track_window, text="Verification Successful")
    elif found == False:
        status_label = Label(track_window, text="")
        status_label_1 = Label(track_window, text="Your Passport")
        status_label_2 = Label(track_window, text="Verification is still pending")
    else:
        status_label = Label(track_window, text="")
        status_label_1 = Label(track_window, text="Incorrect Detail")
        status_label_2 = Label(track_window, text="Check your details")
    status_label.pack()
    status_label_1.pack()
    status_label_2.pack()
    track_window.mainloop()

def login():
    username = e1.get()
    password = e2.get()
    if username == 'admin' and password == 'admin':
        root.destroy()
        admin_window()
    elif check_credentials(username, password):
        root.destroy()
        menu()

def admin_window():
    def approve_all_records():
        with open('approved.csv', 'a', newline='') as approved_file:
            writer = csv.writer(approved_file)
            for record in records_not_approved:
                writer.writerow(record)
        admin_root.destroy()
    admin_root = Tk()
    admin_root.geometry('400x300')
    admin_root.title("Admin Panel")
    records_not_approved = []
    with open('record.csv', newline='') as record_file:
        record_reader = csv.reader(record_file)
        records = list(record_reader)
    with open('approved.csv', newline='') as approved_file:
        approved_reader = csv.reader(approved_file)
        approved_data = set(tuple(row) for row in approved_reader)
    for record in records:
        if tuple(record) not in approved_data:
            records_not_approved.append(record)
    records_label = Label(admin_root, text="Records not approved:")
    records_label.pack()
    records_text = Text(admin_root, height=10, width=50)
    for record in records_not_approved:
        records_text.insert(END, ', '.join(record) + '\n')
    records_text.pack()
    approve_button = Button(admin_root, text="Approve All", command=approve_all_records)
    approve_button.pack(pady=10)
    admin_root.mainloop()

def create_user(username, password):
    with open('users.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([username, password])

def check_credentials(username, password):
    with open('users.csv', newline='') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] == username and row[1] == password:
                return True
    return False

def create_record(name, email, phone, birth, aadhar):
    with open('record.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([name, email, phone, birth, aadhar])

def create():
    def add():
        create_record(entry_1.get(), entry_2.get(), entry_3.get(), entry_4.get(), entry_5.get())
        top.destroy()
    top = Tk()
    top.geometry("300x350")
    top.title("Adding New Passport")
    Name = Label(top, text="Name")
    Name.place(x=30, y=50)
    EMail = Label(top, text="E-Mail")
    EMail.place(x=30, y=90)
    Phone = Label(top, text="Phone")
    Phone.place(x=30, y=130)
    Birth_Cer = Label(top, text="Date of Birth")
    Birth_Cer.place(x=30, y=170)
    Aadhar = Label(top, text="Aadhar")
    Aadhar.place(x=30, y=210)
    entry_1 = Entry(top, width=20)
    entry_1.place(x=140, y=50)
    entry_2 = Entry(top, width=20)
    entry_2.place(x=140, y=90)
    entry_3 = Entry(top, width=20)
    entry_3.place(x=140, y=130)
    entry_4 = Entry(top, width=20)
    entry_4.place(x=140, y=170)
    entry_5 = Entry(top, width=20)
    entry_5.place(x=140, y=210)
    add = Button(top, text="ADD", command=add)
    add.place(x=70, y=280)
    close = Button(top, text="CLOSE", command=top.destroy)
    close.place(x=180, y=280)
    top.mainloop()

def track_page():
    root = Tk()
    root.geometry('300x200')
    root.title("Status Track")
    name = Label(root, text="Name")
    name.place(x=30, y=50)
    passwd = Label(root, text="Phone Number")
    passwd.place(x=30, y=90)
    e1 = Entry(root, width=20)
    e1.place(x=140, y=50)
    e2 = Entry(root, width=20)
    e2.place(x=140, y=90)
    SIGN_IN = Button(root, text="TRACK", command=lambda: track(e1.get(), e2.get()))
    SIGN_IN.place(x=120, y=150)
    root.mainloop()

def menu():
    def on_create():
        t_op.destroy()
        create()
    def op_destroy():
        t_op.destroy()
        again_login()
    t_op = Tk()
    t_op.geometry("250x180")
    t_op.title("Adding New Passport")
    exit_button = Button(t_op, text="Sign Out", command=op_destroy)
    exit_button.place(x=193, y=0)
    new_button = Button(t_op, text="New Passport", command=on_create)
    new_button.place(x=85, y=60)
    Close = Button(t_op, text="Track", command=track_page)
    Close.place(x=105, y=110)
    t_op.mainloop()

def NEW_USER():
    def on_create():
        create_user(entry_1.get(), entry_2.get())
        Root.destroy()
    Root = Tk()
    Root.geometry('300x200')
    Root.title("NEW USER")
    Name = Label(Root, text="User Name")
    Name.place(x=30, y=50)
    Passwd = Label(Root, text="Password")
    Passwd.place(x=30, y=90)
    entry_1 = Entry(Root, width=20)
    entry_1.place(x=140, y=50)
    entry_2 = Entry(Root, width=20)
    entry_2.place(x=140, y=90)
    Create = Button(Root, text="Create", command=on_create)
    Create.place(x=120, y=150)
    Root.mainloop()

def again_login():
    root = Tk()
    root.geometry('300x200')
    root.title("Passport System")
    Name = Label(root, text="Name")
    Name.place(x=30, y=50)
    Passwd = Label(root, text="Password")
    Passwd.place(x=30, y=90)
    e1 = Entry(root, width=20)
    e1.place(x=140, y=50)
    e2 = Entry(root, width=20, show="*")
    e2.place(x=140, y=90)
    SIGN_IN = Button(root, text="SIGN IN", command=login)
    SIGN_IN.place(x=120, y=150)
    root.mainloop()

root = Tk()
root.geometry('300x200')
root.title("Passport System")
Name = Label(root, text="Name")
Name.place(x=30, y=50)
Passwd = Label(root, text="Password")
Passwd.place(x=30, y=90)
e1 = Entry(root, width=20)
e1.place(x=140, y=50)
e2 = Entry(root, width=20, show="*")
e2.place(x=140, y=90)
SIGN_IN = Button(root, text="SIGN IN", command=login)
SIGN_IN.place(x=60, y=150)
SIGN_UP = Button(root, text="SIGN UP", command=NEW_USER)
SIGN_UP.place(x=190, y=150)
root.mainloop()