from tkinter import *
import csv
def record_check():
    with open('record.csv', newline='') as file:
        reader = csv.reader(file)
        records_data = list(reader)
    with open('approved.csv', newline='') as approved_file:
        approved_reader = csv.reader(approved_file)
        approved_data = set(tuple(row) for row in approved_reader)
    difference = [record for record in records_data if tuple(record) not in approved_data]
    return difference
def track(name, phone):
    found = 0
    with open('approved.csv', newline='') as approved_file:
        reader = csv.reader(approved_file)
        for row in reader:
            if row[0] == name and row[2] == phone:
                found = 1
    track_1(found)
def track_1(found):
    track_window = Tk()
    track_window.geometry('200x80')
    track_window.title("Passport Verification Status")
    if found == 1:
        status_label = Label(track_window, text="Your Passport")
        status_label_2 = Label(track_window, text="Verification Successful")
    else:
        status_label = Label(track_window, text="Your Passport ")
        status_label_2 = Label(track_window, text="verification is still pending")
    status_label.pack()
    status_label_2.pack()
    track_window.mainloop()
def login():
    if check_credentials(e1.get(), e2.get()):
        root.destroy()
        menu()
def create_user(username, password):
    with open('users.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([username, password])
def check_credentials(username, password):
    with open('users.csv', newline='') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] == username and row[1] == password:
                return True
    return False
def create_record(name, email, phone, birth, aadhar):
    with open('record.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([name, email, phone, birth, aadhar])
def create():
    def add():
        create_record(entry_1.get(), entry_2.get(), entry_3.get(), entry_4.get(), entry_5.get())
        top.destroy()
    top = Tk()
    top.geometry("300x350")
    top.title("Adding New Passport")
    Name = Label(top, text="Name").place(x=30, y=50)
    EMail = Label(top, text="E-Mail").place(x=30, y=90)
    Phone = Label(top, text="Phone").place(x=30, y=130)
    Birth_Cer = Label(top, text="Date of Birth").place(x=30, y=170)
    Aadhar = Label(top, text="Aadhar").place(x=30, y=210)
    entry_1 = Entry(top, width=20).place(x=140, y=50)
    entry_2 = Entry(top, width=20).place(x=140, y=90)
    entry_3 = Entry(top, width=20).place(x=140, y=130)
    entry_4 = Entry(top, width=20).place(x=140, y=170)
    entry_5 = Entry(top, width=20).place(x=140, y=210)
    Add = Button(top, text="ADD", command=add).place(x=70, y=280)
    Close = Button(top, text="CLOSE", command=top.destroy)
    Close.place(x=180, y=280)
    top.mainloop()
def track_page():
    root = Tk()
    root.geometry('300x200')
    root.title("Status Track")
    Name = Label(root, text="Name").place(x=30, y=50)
    Passwd = Label(root, text="Phone Number").place(x=30, y=90)
    e1 = Entry(root, width=20).place(x=140, y=50)
    e2 = Entry(root, width=20).place(x=140, y=90)
    SIGN_IN = Button(root, text="TRACK", command=lambda: track(e1.get(), e2.get())).place(x=120, y=150)
    root.mainloop()
def menu():
    def on_create():
        t_op.destroy()
        create()
    def op_destroy():
        t_op.destroy()
        again_login()
    t_op = Tk()
    t_op.geometry("250x180")
    t_op.title("Adding New Passport")
    exit = Button(t_op, text="Sign Out", command=op_destroy).place(x=193, y=0)
    new = Button(t_op, text="New Passport", command=on_create).place(x=85, y=60)
    Close = Button(t_op, text="Track", command=track_page).place(x=105, y=110)
    t_op.mainloop()
def NEW_USER():
    def on_create():
        create_user(entry_1.get(), entry_2.get())
        Root.destroy()
    Root = Tk()
    Root.geometry('300x200')
    Root.title("NEW USER")
    Name = Label(Root, text="User Name").place(x=30, y=50)
    Passwd = Label(Root, text="Password").place(x=30, y=90)
    entry_1 = Entry(Root, width=20).place(x=140, y=50)
    entry_2 = Entry(Root, width=20).place(x=140, y=90)
    Create = Button(Root, text="Create", command=on_create)
    Create.place(x=120, y=150)
    Root.mainloop()
def again_login():
    root = Tk()
    root.geometry('300x200')
    root.title("Passport System")
    Name = Label(root, text="Name").place(x=30, y=50)
    Passwd = Label(root, text="Password").place(x=30, y=90)
    e1 = Entry(root, width=20).place(x=140, y=50)
    e2 = Entry(root, width=20).place(x=140, y=90)
    SIGN_IN = Button(root, text="SIGN IN", command=login).place(x=120, y=150)
    root.mainloop()
root = Tk()
root.geometry('300x200')
root.title("Passport System")
Name = Label(root, text="Name").place(x=30, y=50)
Passwd = Label(root, text="Password").place(x=30, y=90)
e1 = Entry(root, width=20).place(x=140, y=50)
e2 = Entry(root, width=20).place(x=140, y=90)
SIGN_IN = Button(root, text="SIGN IN", command=login).place(x=60, y=150)
SIGN_UP = Button(root, text="SIGN UP", command=NEW_USER).place(x=190, y=150)
root.mainloop()